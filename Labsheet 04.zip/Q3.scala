object Q3 {

    def toUpper(str: String): String = {
      str.toUpperCase;
    }

    def toLower(str: String): String = {
      str.toLowerCase;
    }

    def formatNames(name: String)(formatFunc: String => String): String = {
      formatFunc(name)
    }

    def main(args: Array[String]): Unit = {
      val name = List("BENNEY", "Niroshan", "saman", "KumarA")

      for (name <- name) {
        var upperCaseName = formatNames(name)(toUpper)
        var lowerCaseName = formatNames(name)(toLower)

        println(upperCaseName);
        println(lowerCaseName);
      }
    }
}
